# **App Name**: IPL Mind Reader

## Core Features:

- AI Dynamic Questioning Tool: An adaptive reasoning engine that uses tools to analyze player/team attributes and generate the most mathematically efficient yes/no questions to narrow down the target within 15 turns.
- Live Confidence Dashboard: A high-tension UI overlay displaying the AI's current certainty levels, questions remaining, and live session duration.
- Adaptive Personality Engine: Dynamic shift in AI responses and avatar expressions based on game states like 'Confident', 'Narrowing', or 'Panic' as the endgame approaches.
- IPL Entity Store: A robust repository of historic IPL players, teams, and iconic matches used for verification and candidate narrowing.
- Real-time Leaderboards: Persistent global rankings tracked in Firestore to showcase users with the highest win streaks and fastest session times.
- Cinematic Visual Feed: A dark, stadium-themed gaming interface utilizing Framer Motion for suspenseful transitions and glowing micro-interactions.
- Multi-category Onboarding: A slick entry flow allowing players to select their category—Legendary Player, Iconic Team, or Historic Match.

## Style Guidelines:

- Primary Color: Electric Stadium Blue (#3B71F7) representing the high-tech, cinematic IPL energy.
- Background Color: Deep Midnight Navy (#0A0C11) to evoke the high-contrast atmosphere of a night-match stadium.
- Accent Color: Neon Indigo (#7D6BFF) used for highlighting AI mood shifts and reactive confidence elements.
- Headline font: 'Space Grotesk' for a computerized, tech-forward scientific feel; Body font: 'Inter' for modern, objective readability in rapid-fire questioning.
- A centralized chat-style conversational interface featuring large, cinematic touch targets for mobile-first gameplay.
- Sleek, minimalist vector icons representing IPL stats (bat, ball, stumps) with subtle neon glow effects.
- Intense suspense transitions using staggered layout reveals and a breathing background that syncs with the AI's confidence levels.