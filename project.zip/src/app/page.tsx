'use client';

import { motion } from 'framer-motion';
import { useRouter } from 'next/navigation';
import { useGameStore, Category } from '@/lib/game-store';
import CategoryCard from '@/components/game/CategoryCard';
import { Button } from '@/components/ui/button';
import { Zap, PlayCircle, BarChart3, Users as UsersIcon } from 'lucide-react';

export default function LandingPage() {
  const router = useRouter();
  const startGame = useGameStore((state) => state.startGame);

  const categories = [
    { id: 'player' as Category, title: 'IPL Legends', description: 'Think of any iconic player, from retired greats to current superstars.' },
    { id: 'team' as Category, title: 'Epic Franchises', description: 'Focus on a team, its legacy, city, or its distinct jersey colors.' },
    { id: 'match' as Category, title: 'Classic Moments', description: 'Recall a historic match, a dramatic final, or a record-breaking game.' },
    { id: 'surprise' as Category, title: 'Surprise Me', description: 'Let the AI pick a random category and challenge your IPL knowledge.' },
  ];

  const handleSelect = (category: Category) => {
    startGame(category);
    router.push('/game');
  };

  return (
    <div className="container mx-auto px-4 py-12 md:py-20 flex flex-col items-center">
      {/* Hero Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center max-w-3xl mb-16 space-y-6"
      >
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary text-xs font-bold uppercase tracking-widest">
          <Zap className="w-3 h-3" /> AI-Powered Challenge
        </div>
        
        <h1 className="text-5xl md:text-7xl font-headline font-bold leading-tight">
          Think of ANY <span className="text-primary">IPL Legend.</span>
        </h1>
        
        <p className="text-lg md:text-xl text-muted-foreground font-medium">
          The most advanced Cricket AI in the world. I will guess who or what you're thinking of in exactly 15 questions. 
        </p>
        
        <div className="flex flex-wrap justify-center gap-4 pt-4">
          <Button size="lg" className="rounded-full h-14 px-8 text-lg font-bold gap-2 neon-glow-blue" onClick={() => handleSelect('player')}>
            <PlayCircle className="w-5 h-5" /> Quick Start
          </Button>
          <Button variant="outline" size="lg" className="rounded-full h-14 px-8 text-lg font-bold gap-2 glass">
            <BarChart3 className="w-5 h-5" /> Leaderboard
          </Button>
        </div>
      </motion.div>

      {/* Category Selection */}
      <div className="w-full max-w-6xl grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {categories.map((cat, idx) => (
          <motion.div
            key={cat.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 * (idx + 1) }}
          >
            <CategoryCard {...cat} onSelect={handleSelect} />
          </motion.div>
        ))}
      </div>

      {/* Global Stats Preview */}
      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        className="w-full max-w-5xl mt-24 p-8 glass rounded-3xl grid grid-cols-1 md:grid-cols-3 gap-8 text-center"
      >
        <div className="space-y-1">
          <h4 className="text-4xl font-headline font-bold text-primary">450K+</h4>
          <p className="text-sm font-bold text-muted-foreground uppercase tracking-wider">Games Played</p>
        </div>
        <div className="space-y-1 border-y md:border-y-0 md:border-x border-white/10 py-8 md:py-0">
          <h4 className="text-4xl font-headline font-bold text-secondary">94%</h4>
          <p className="text-sm font-bold text-muted-foreground uppercase tracking-wider">AI Accuracy</p>
        </div>
        <div className="space-y-1">
          <h4 className="text-4xl font-headline font-bold text-foreground">1.2m</h4>
          <p className="text-sm font-bold text-muted-foreground uppercase tracking-wider">IPL Entities</p>
        </div>
      </motion.div>

      {/* Leaderboard Preview */}
      <div className="w-full max-w-4xl mt-32 space-y-8">
        <div className="flex justify-between items-end">
          <h2 className="text-3xl font-headline font-bold">Top Mind Readers</h2>
          <Button variant="link" className="text-primary font-bold">View All Rankings →</Button>
        </div>
        
        <div className="space-y-3">
          {[
            { rank: 1, name: 'CricketWizard_88', score: '24 win streak', avatar: '1' },
            { rank: 2, name: 'MumbaiPaltanFans', score: '19 win streak', avatar: '2' },
            { rank: 3, name: 'ThalaForever', score: '15 win streak', avatar: '3' },
          ].map((user) => (
            <div key={user.rank} className="flex items-center gap-4 p-4 glass rounded-2xl hover:bg-white/10 transition-colors">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold ${user.rank === 1 ? 'bg-yellow-500 text-black' : 'bg-muted'}`}>
                {user.rank}
              </div>
              <div className="flex-1 font-bold text-lg">{user.name}</div>
              <div className="text-primary font-bold">{user.score}</div>
            </div>
          ))}
        </div>
      </div>

      <footer className="mt-32 py-8 text-center text-muted-foreground text-sm border-t border-white/5 w-full">
        <p>© 2025 IPL Mind Reader. Powered by Gemini 2.5 Flash.</p>
      </footer>
    </div>
  );
}