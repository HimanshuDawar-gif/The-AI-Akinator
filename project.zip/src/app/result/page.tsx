'use client';

import { motion } from 'framer-motion';
import { useRouter } from 'next/navigation';
import { useGameStore } from '@/lib/game-store';
import { Button } from '@/components/ui/button';
import { Trophy, RotateCcw, Share2, Award, Zap, Clock } from 'lucide-react';
import { useEffect } from 'react';

export default function ResultPage() {
  const router = useRouter();
  const { 
    isGameOver, 
    isAiWinner, 
    finalGuess, 
    finalGuessReasoning, 
    questionNumber, 
    startTime, 
    endTime, 
    resetGame,
    streak 
  } = useGameStore();

  useEffect(() => {
    if (!isGameOver) {
      router.push('/');
    }
  }, [isGameOver, router]);

  if (!isGameOver) return null;

  const duration = endTime && startTime ? Math.floor((endTime - startTime) / 1000) : 0;

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-2xl glass rounded-[2.5rem] overflow-hidden p-8 md:p-12 text-center space-y-8"
      >
        <div className="flex justify-center">
          <motion.div
            initial={{ rotate: -15, scale: 0 }}
            animate={{ rotate: 0, scale: 1 }}
            transition={{ type: 'spring', damping: 10 }}
            className={`w-24 h-24 rounded-full flex items-center justify-center ${isAiWinner ? 'bg-secondary text-secondary-foreground neon-glow-indigo' : 'bg-primary text-primary-foreground neon-glow-blue'}`}
          >
            {isAiWinner ? <Trophy className="w-12 h-12" /> : <Award className="w-12 h-12" />}
          </motion.div>
        </div>

        <div className="space-y-4">
          <h1 className="text-4xl md:text-6xl font-headline font-bold">
            {isAiWinner ? 'I WON!' : 'YOU WON!'}
          </h1>
          <p className="text-xl text-muted-foreground font-medium">
            {isAiWinner ? "I've deciphered your thoughts." : "You've outsmarted the machine."}
          </p>
        </div>

        <div className="py-8 border-y border-white/5 space-y-6">
          <div className="flex flex-col items-center">
            <span className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-2">The AI's Final Declaration</span>
            <h2 className="text-3xl md:text-5xl font-headline font-bold text-primary italic">
              "{finalGuess}"
            </h2>
          </div>
          <p className="text-muted-foreground italic max-w-md mx-auto leading-relaxed">
            {finalGuessReasoning}
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-6 pt-4">
          <div className="flex flex-col items-center glass p-4 rounded-2xl">
            <Zap className="w-5 h-5 text-secondary mb-2" />
            <span className="text-[10px] font-bold text-muted-foreground uppercase">Questions</span>
            <span className="text-xl font-headline font-bold">{questionNumber}</span>
          </div>
          <div className="flex flex-col items-center glass p-4 rounded-2xl">
            <Clock className="w-5 h-5 text-primary mb-2" />
            <span className="text-[10px] font-bold text-muted-foreground uppercase">Time Taken</span>
            <span className="text-xl font-headline font-bold">{duration}s</span>
          </div>
          <div className="flex flex-col items-center glass p-4 rounded-2xl col-span-2 md:col-span-1">
            <Trophy className="w-5 h-5 text-yellow-500 mb-2" />
            <span className="text-[10px] font-bold text-muted-foreground uppercase">Current Streak</span>
            <span className="text-xl font-headline font-bold">{streak}</span>
          </div>
        </div>

        <div className="flex flex-col md:flex-row gap-4 pt-8">
          <Button 
            onClick={() => { resetGame(); router.push('/'); }} 
            size="lg" 
            className="flex-1 rounded-2xl h-14 text-lg font-bold gap-2 neon-glow-blue"
          >
            <RotateCcw className="w-5 h-5" /> Play Again
          </Button>
          <Button 
            variant="outline" 
            size="lg" 
            className="flex-1 rounded-2xl h-14 text-lg font-bold gap-2 glass"
          >
            <Share2 className="w-5 h-5" /> Share Result
          </Button>
        </div>
      </motion.div>
    </div>
  );
}