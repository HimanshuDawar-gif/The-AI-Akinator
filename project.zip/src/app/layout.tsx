import type {Metadata} from 'next';
import './globals.css';
import { Toaster } from "@/components/ui/toaster";

export const metadata: Metadata = {
  title: 'IPL Mind Reader | AI Cricket Challenge',
  description: 'Can the AI guess your favorite IPL legend in 15 questions?',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet" />
      </head>
      <body className="font-body antialiased selection:bg-primary/30">
        <div className="particle-bg" />
        <div className="stadium-gradient fixed inset-0 pointer-events-none" />
        <main className="relative z-10 min-h-screen">
          {children}
        </main>
        <Toaster />
      </body>
    </html>
  );
}