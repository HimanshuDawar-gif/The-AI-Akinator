'use server';

import { generateAiQuestion, GenerateQuestionInput } from '@/ai/flows/ai-dynamic-question-engine';
import { aiFinalGuessLogic } from '@/ai/flows/ai-final-guess-logic';
import { IPL_ENTITIES } from '@/lib/entities';

export async function getNextQuestion(input: Partial<GenerateQuestionInput>) {
  const fullInput: GenerateQuestionInput = {
    category: input.category || 'player',
    previousQuestionsAsked: input.previousQuestionsAsked || [],
    previousQuestionAttributeKeys: input.previousQuestionAttributeKeys || [],
    knownAttributes: input.knownAttributes || {},
    excludedAttributes: input.excludedAttributes || {},
    questionNumber: input.questionNumber || 1,
    confidenceLevel: input.confidenceLevel || 5,
    aiMood: input.aiMood || 'discovery',
    allEntities: IPL_ENTITIES as any,
  };

  return await generateAiQuestion(fullInput);
}

export async function makeFinalGuess(category: 'player' | 'team' | 'match' | 'surprise', candidates: string[]) {
  return await aiFinalGuessLogic({ category: category as any, candidates });
}
