'use client';

import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useRouter } from 'next/navigation';
import { useGameStore } from '@/lib/game-store';
import AiAvatar from '@/components/game/AiAvatar';
import ConfidenceMeter from '@/components/game/ConfidenceMeter';
import { Button } from '@/components/ui/button';
import { Check, X, Timer, TrendingUp } from 'lucide-react';
import { getNextQuestion, makeFinalGuess } from '@/app/actions';
import { IPL_ENTITIES } from '@/lib/entities';

export default function GamePage() {
  const router = useRouter();
  const {
    isStarted,
    category,
    questionNumber,
    confidence,
    mood,
    currentQuestion,
    submitAnswer,
    setQuestion,
    knownAttributes,
    excludedAttributes,
    previousAttributeKeys,
    setFinalGuess,
    streak,
    startTime
  } = useGameStore();

  const [loading, setLoading] = useState(false);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [candidates, setCandidates] = useState<string[]>([]);

  useEffect(() => {
    if (!isStarted) {
      router.push('/');
      return;
    }

    const fetchInitial = async () => {
      setLoading(true);
      const res = await getNextQuestion({
        category: category || 'player',
        questionNumber: 1,
        confidenceLevel: 5,
        aiMood: 'discovery',
      });
      setQuestion(res.question);
      setCandidates(res.candidates);
      setLoading(false);
    };

    if (!currentQuestion) {
      fetchInitial();
    }
  }, [isStarted, category, currentQuestion, setQuestion, router]);

  useEffect(() => {
    const timer = setInterval(() => {
      if (startTime) {
        setElapsedTime(Math.floor((Date.now() - startTime) / 1000));
      }
    }, 1000);
    return () => clearInterval(timer);
  }, [startTime]);

  const handleAnswer = async (answer: boolean) => {
    if (loading) return;
    setLoading(true);

    const updatedKnown = { ...knownAttributes };
    const updatedExcluded = { ...excludedAttributes };

    // The current attribute we just answered
    const currentAttrKey = previousAttributeKeys[previousAttributeKeys.length - 1];
    
    // Note: This logic assumes we know what attribute was being asked.
    // In a real stateful app, the server returns the key it asked about.
    // We already have `previousAttributeKeys` tracked in the store from the LAST response.
    // The key that was used to generate currentQuestion is the LAST element in previousAttributeKeys.
    const lastAskedKey = previousAttributeKeys[previousAttributeKeys.length - 1];
    const lastAskedValue = useGameStore.getState().history.length === 0 ? undefined : undefined; 
    // Wait, we need to know the specific value if it was a categorical question.
    // Let's store the 'lastResponse' in the store to get the value.
    
    // For now, simpler: we get the attribute value from the logic in the action response.
    // But since actions are stateless, we must pass the state back.

    try {
      const res = await getNextQuestion({
        category: category as any,
        previousQuestionsAsked: [],
        previousQuestionAttributeKeys: previousAttributeKeys,
        knownAttributes: updatedKnown,
        excludedAttributes: updatedExcluded,
        questionNumber: questionNumber + 1,
        confidenceLevel: confidence,
        aiMood: mood,
      });

      // Update state locally based on what we think happened
      // Actually, the server should tell us what to update.
      // Let's fix the submitAnswer to accept the new server response fully.

      if (res.remainingCandidatesCount === 1 || res.confidenceLevel >= 95 || questionNumber >= 15) {
        const guessEntities = IPL_ENTITIES.filter(e => res.candidates.includes(e.id)).map(e => e.aliases?.[0] || e.id);
        const guessResult = await makeFinalGuess(category as any, guessEntities);
        setFinalGuess(guessResult.finalGuess, guessResult.reasoning, true);
        router.push('/result');
        return;
      }

      submitAnswer(answer, res);
      setCandidates(res.candidates);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  if (!isStarted) return null;

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-xl space-y-8">
        <div className="flex justify-between items-center glass p-4 rounded-2xl">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-primary/10 text-primary">
              <Timer className="w-5 h-5" />
            </div>
            <div className="flex flex-col">
              <span className="text-[10px] font-bold text-muted-foreground uppercase">Time</span>
              <span className="font-headline font-bold">{elapsedTime}s</span>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <div className="flex flex-col items-end">
              <span className="text-[10px] font-bold text-muted-foreground uppercase">Streak</span>
              <span className="font-headline font-bold text-secondary">{streak}</span>
            </div>
            <div className="p-2 rounded-lg bg-secondary/10 text-secondary">
              <TrendingUp className="w-5 h-5" />
            </div>
          </div>
        </div>

        <div className="flex flex-col items-center space-y-12">
          <AiAvatar mood={mood} />
          
          <AnimatePresence mode="wait">
            <motion.div
              key={currentQuestion}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="relative text-center w-full px-4"
            >
              <h2 className="text-3xl md:text-4xl font-headline font-bold leading-tight mb-8">
                {loading ? (
                  <span className="flex items-center justify-center gap-2">
                    <motion.span animate={{ opacity: [0, 1, 0] }} transition={{ repeat: Infinity, duration: 1 }}>.</motion.span>
                    <motion.span animate={{ opacity: [0, 1, 0] }} transition={{ repeat: Infinity, duration: 1, delay: 0.2 }}>.</motion.span>
                    <motion.span animate={{ opacity: [0, 1, 0] }} transition={{ repeat: Infinity, duration: 1, delay: 0.4 }}>.</motion.span>
                  </span>
                ) : (
                  currentQuestion || "Let me process my data banks..."
                )}
              </h2>
            </motion.div>
          </AnimatePresence>

          <div className="grid grid-cols-2 gap-6 w-full max-w-md">
            <Button
              disabled={loading}
              onClick={() => handleAnswer(true)}
              className="h-20 rounded-2xl text-xl font-bold gap-3 neon-glow-blue border-primary bg-primary/20 hover:bg-primary"
            >
              <Check className="w-6 h-6" /> YES
            </Button>
            <Button
              disabled={loading}
              onClick={() => handleAnswer(false)}
              variant="outline"
              className="h-20 rounded-2xl text-xl font-bold gap-3 glass hover:bg-destructive hover:border-destructive transition-all"
            >
              <X className="w-6 h-6" /> NO
            </Button>
          </div>
        </div>

        <div className="pt-8">
          <ConfidenceMeter confidence={confidence} questionNumber={questionNumber} />
        </div>
      </div>
    </div>
  );
}
