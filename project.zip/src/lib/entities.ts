export const IPL_ENTITIES = [
  // Players
  {
    id: 'ms_dhoni',
    type: 'player',
    aliases: ['MS Dhoni', 'Thala', 'Captain Cool'],
    popularity: 100,
    attributes: { captain: true, indian: true, wicketkeeper: true, team: ['CSK', 'RPS'], retired: true, trophies: 5, right_handed: true }
  },
  {
    id: 'virat_kohli',
    type: 'player',
    aliases: ['Virat Kohli', 'King Kohli', 'Cheeku'],
    popularity: 99,
    attributes: { captain: true, indian: true, wicketkeeper: false, team: ['RCB'], retired: false, trophies: 0, orange_cap: true, right_handed: true }
  },
  {
    id: 'rohit_sharma',
    type: 'player',
    aliases: ['Rohit Sharma', 'Hitman'],
    popularity: 98,
    attributes: { captain: true, indian: true, wicketkeeper: false, team: ['MI', 'Deccan Chargers'], retired: false, trophies: 6, right_handed: true }
  },
  {
    id: 'hardik_pandya',
    type: 'player',
    aliases: ['Hardik Pandya', 'Kung Fu Pandya'],
    popularity: 92,
    attributes: { captain: true, indian: true, wicketkeeper: false, team: ['MI', 'GT'], retired: false, trophies: 5, allrounder: true, pace_bowler: true, right_handed: true }
  },
  {
    id: 'rashid_khan',
    type: 'player',
    aliases: ['Rashid Khan', 'Karamati Khan'],
    popularity: 90,
    attributes: { captain: false, indian: false, wicketkeeper: false, team: ['SRH', 'GT'], retired: false, purple_cap: false, spin: true, right_handed: true }
  },
  {
    id: 'chris_gayle',
    type: 'player',
    aliases: ['Chris Gayle', 'Universe Boss'],
    popularity: 95,
    attributes: { captain: false, indian: false, wicketkeeper: false, team: ['RCB', 'PBKS', 'KKR'], retired: true, six_machine: true, left_handed: true }
  },
  {
    id: 'ab_de_villiers',
    type: 'player',
    aliases: ['AB de Villiers', 'Mr. 360'],
    popularity: 96,
    attributes: { captain: false, indian: false, wicketkeeper: true, team: ['RCB', 'Delhi Daredevils'], retired: true, legendary: true, right_handed: true }
  },
  {
    id: 'suresh_raina',
    type: 'player',
    aliases: ['Suresh Raina', 'Mr. IPL'],
    popularity: 94,
    attributes: { captain: false, indian: true, wicketkeeper: false, team: ['CSK', 'GL'], retired: true, left_handed: true }
  },
  {
    id: 'kl_rahul',
    type: 'player',
    aliases: ['KL Rahul'],
    popularity: 93,
    attributes: { captain: true, indian: true, wicketkeeper: true, team: ['LSG', 'PBKS', 'RCB', 'SRH'], retired: false, right_handed: true, opening_batsman: true }
  },
  {
    id: 'david_warner',
    type: 'player',
    aliases: ['David Warner'],
    popularity: 92,
    attributes: { captain: true, indian: false, wicketkeeper: false, team: ['SRH', 'DC'], retired: false, left_handed: true, trophies: 1, orange_cap: true }
  },
  {
    id: 'jasprit_bumrah',
    type: 'player',
    aliases: ['Jasprit Bumrah', 'Boom Boom'],
    popularity: 97,
    attributes: { captain: false, indian: true, wicketkeeper: false, team: ['MI'], retired: false, pace_bowler: true, trophies: 5, purple_cap: true }
  },
  {
    id: 'ravindra_jadeja',
    type: 'player',
    aliases: ['Ravindra Jadeja', 'Sir Jadeja'],
    popularity: 95,
    attributes: { captain: true, indian: true, wicketkeeper: false, team: ['CSK', 'RR', 'GL'], retired: false, left_handed: true, allrounder: true, spin: true, trophies: 4 }
  },
  {
    id: 'shubman_gill',
    type: 'player',
    aliases: ['Shubman Gill', 'Prince'],
    popularity: 94,
    attributes: { captain: true, indian: true, wicketkeeper: false, team: ['GT', 'KKR'], retired: false, right_handed: true, orange_cap: true }
  },
  {
    id: 'sunil_narine',
    type: 'player',
    aliases: ['Sunil Narine'],
    popularity: 93,
    attributes: { captain: false, indian: false, wicketkeeper: false, team: ['KKR'], retired: false, spin: true, allrounder: true, trophies: 3, left_handed: true }
  },
  
  // Teams
  {
    id: 'csk',
    type: 'team',
    aliases: ['Chennai Super Kings', 'CSK', 'Yellow Army'],
    popularity: 100,
    attributes: { city: 'Chennai', color: 'Yellow', trophies: 5, active: true, popular: true }
  },
  {
    id: 'mi',
    type: 'team',
    aliases: ['Mumbai Indians', 'MI', 'Paltan'],
    popularity: 99,
    attributes: { city: 'Mumbai', color: 'Blue', trophies: 5, active: true, popular: true }
  },
  {
    id: 'rcb',
    type: 'team',
    aliases: ['Royal Challengers Bengaluru', 'RCB'],
    popularity: 98,
    attributes: { city: 'Bengaluru', color: 'Red', trophies: 0, active: true, popular: true }
  },
  {
    id: 'kkr',
    type: 'team',
    aliases: ['Kolkata Knight Riders', 'KKR'],
    popularity: 95,
    attributes: { city: 'Kolkata', color: 'Purple', trophies: 3, active: true }
  },
  {
    id: 'gt',
    type: 'team',
    aliases: ['Gujarat Titans', 'GT'],
    popularity: 90,
    attributes: { city: 'Ahmedabad', color: 'Dark Blue', trophies: 1, active: true }
  },
  
  // Matches
  {
    id: 'ipl_2008_final',
    type: 'match',
    aliases: ['IPL 2008 Final', 'RR vs CSK 2008'],
    popularity: 85,
    attributes: { year: 2008, winner: 'RR', classic: true, first_ever: true }
  },
  {
    id: 'ipl_2019_final',
    type: 'match',
    aliases: ['IPL 2019 Final', 'MI vs CSK 1 run win'],
    popularity: 90,
    attributes: { year: 2019, winner: 'MI', thrill: true, one_run_win: true }
  },
  {
    id: 'ipl_2024_final',
    type: 'match',
    aliases: ['IPL 2024 Final', 'KKR vs SRH'],
    popularity: 88,
    attributes: { year: 2024, winner: 'KKR', dominant: true }
  }
];
