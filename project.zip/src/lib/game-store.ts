import { create } from 'zustand';

export type Category = 'player' | 'team' | 'match' | 'surprise';
export type AiMood = 'discovery' | 'narrowing' | 'confident' | 'panic';

interface GameState {
  isStarted: boolean;
  category: Category | null;
  questionNumber: number;
  remainingQuestions: number;
  confidence: number;
  mood: AiMood;
  history: { question: string; answer: boolean }[];
  knownAttributes: Record<string, any>;
  excludedAttributes: Record<string, any>;
  previousAttributeKeys: string[];
  lastAttributeValue: any;
  currentQuestion: string | null;
  isGameOver: boolean;
  isAiWinner: boolean;
  finalGuess: string | null;
  finalGuessReasoning: string | null;
  startTime: number | null;
  endTime: number | null;
  streak: number;

  startGame: (category: Category) => void;
  submitAnswer: (answer: boolean, nextQuestionData: any) => void;
  setFinalGuess: (guess: string, reasoning: string, isCorrect: boolean) => void;
  resetGame: () => void;
  setQuestion: (question: string) => void;
}

export const useGameStore = create<GameState>((set) => ({
  isStarted: false,
  category: null,
  questionNumber: 0,
  remainingQuestions: 15,
  confidence: 0,
  mood: 'discovery',
  history: [],
  knownAttributes: {},
  excludedAttributes: {},
  previousAttributeKeys: [],
  lastAttributeValue: null,
  currentQuestion: null,
  isGameOver: false,
  isAiWinner: false,
  finalGuess: null,
  finalGuessReasoning: null,
  startTime: null,
  endTime: null,
  streak: 0,

  startGame: (category) => set({
    isStarted: true,
    category,
    questionNumber: 1,
    remainingQuestions: 15,
    confidence: 5,
    mood: 'discovery',
    history: [],
    knownAttributes: {},
    excludedAttributes: {},
    previousAttributeKeys: [],
    lastAttributeValue: null,
    isGameOver: false,
    isAiWinner: false,
    finalGuess: null,
    finalGuessReasoning: null,
    startTime: Date.now(),
    endTime: null,
  }),

  submitAnswer: (answer, nextQuestionData) => set((state) => {
    const lastQuestion = state.currentQuestion || '';
    
    // The previous question was asked using 'lastAttributeKey' and 'lastAttributeValue'
    const lastKey = state.previousAttributeKeys[state.previousAttributeKeys.length - 1];
    const lastVal = state.lastAttributeValue;

    const newKnown = { ...state.knownAttributes };
    const newExcluded = { ...state.excludedAttributes };

    if (lastKey) {
      if (answer) {
        newKnown[lastKey] = lastVal;
      } else {
        newExcluded[lastKey] = lastVal;
      }
    }

    return {
      history: [...state.history, { question: lastQuestion, answer }],
      questionNumber: state.questionNumber + 1,
      remainingQuestions: state.remainingQuestions - 1,
      confidence: nextQuestionData.confidenceLevel,
      mood: nextQuestionData.aiMood,
      currentQuestion: nextQuestionData.question,
      knownAttributes: newKnown,
      excludedAttributes: newExcluded,
      previousAttributeKeys: [...state.previousAttributeKeys, nextQuestionData.bestAttributeKey],
      lastAttributeValue: nextQuestionData.bestAttributeValue,
    };
  }),

  setFinalGuess: (guess, reasoning, isCorrect) => set((state) => ({
    isGameOver: true,
    isAiWinner: isCorrect,
    finalGuess: guess,
    finalGuessReasoning: reasoning,
    endTime: Date.now(),
    streak: isCorrect ? state.streak + 1 : 0,
  })),

  resetGame: () => set({
    isStarted: false,
    category: null,
    questionNumber: 0,
    remainingQuestions: 15,
    confidence: 0,
    mood: 'discovery',
    isGameOver: false,
    currentQuestion: null,
    knownAttributes: {},
    excludedAttributes: {},
    previousAttributeKeys: [],
    lastAttributeValue: null,
  }),

  setQuestion: (question) => set({ currentQuestion: question }),
}));
