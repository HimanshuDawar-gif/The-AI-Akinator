'use client';

import { motion, AnimatePresence } from 'framer-motion';
import { AiMood } from '@/lib/game-store';
import { Cpu, Zap, Search, AlertTriangle } from 'lucide-react';

interface AiAvatarProps {
  mood: AiMood;
}

export default function AiAvatar({ mood }: AiAvatarProps) {
  const getMoodConfig = () => {
    switch (mood) {
      case 'confident':
        return {
          icon: <Zap className="w-12 h-12 text-secondary" />,
          color: 'bg-secondary/20 border-secondary',
          glow: 'neon-glow-indigo',
          message: "I think I know who you're thinking of...",
          scale: 1.1,
        };
      case 'panic':
        return {
          icon: <AlertTriangle className="w-12 h-12 text-destructive" />,
          color: 'bg-destructive/20 border-destructive',
          glow: 'shadow-[0_0_20px_rgba(239,68,68,0.5)]',
          message: "Wait, this is harder than I thought!",
          scale: 0.95,
          animate: { x: [0, -5, 5, -5, 5, 0] },
        };
      case 'narrowing':
        return {
          icon: <Search className="w-12 h-12 text-primary" />,
          color: 'bg-primary/20 border-primary',
          glow: 'neon-glow-blue',
          message: "The search space is shrinking...",
          scale: 1.05,
        };
      default:
        return {
          icon: <Cpu className="w-12 h-12 text-primary" />,
          color: 'bg-primary/10 border-primary/50',
          glow: 'shadow-none',
          message: "Analyzing possibilities...",
          scale: 1,
        };
    }
  };

  const config = getMoodConfig();

  return (
    <div className="flex flex-col items-center gap-6">
      <motion.div
        animate={{
          scale: config.scale,
          ...(config.animate || {}),
        }}
        transition={{ type: 'spring', stiffness: 300, damping: 20 }}
        className={`relative w-28 h-28 rounded-full border-2 flex items-center justify-center ${config.color} ${config.glow} transition-all duration-500`}
      >
        <AnimatePresence mode="wait">
          <motion.div
            key={mood}
            initial={{ opacity: 0, rotateY: 90 }}
            animate={{ opacity: 1, rotateY: 0 }}
            exit={{ opacity: 0, rotateY: -90 }}
            transition={{ duration: 0.3 }}
          >
            {config.icon}
          </motion.div>
        </AnimatePresence>
        
        {/* Orbiting particles */}
        <div className="absolute inset-0 animate-spin-slow">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-2 h-2 rounded-full bg-secondary" />
        </div>
      </motion.div>
      
      <motion.p
        key={config.message}
        initial={{ opacity: 0, y: 5 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-sm font-medium text-muted-foreground italic text-center max-w-[200px]"
      >
        {config.message}
      </motion.p>
    </div>
  );
}