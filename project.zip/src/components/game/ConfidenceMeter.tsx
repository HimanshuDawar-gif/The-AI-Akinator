'use client';

import { motion } from 'framer-motion';
import { Progress } from '@/components/ui/progress';

interface ConfidenceMeterProps {
  confidence: number;
  questionNumber: number;
}

export default function ConfidenceMeter({ confidence, questionNumber }: ConfidenceMeterProps) {
  return (
    <div className="w-full space-y-3">
      <div className="flex justify-between items-end text-sm">
        <div className="flex flex-col">
          <span className="text-muted-foreground uppercase tracking-wider text-[10px] font-bold">Confidence</span>
          <span className="text-xl font-headline font-bold text-primary">{confidence}%</span>
        </div>
        <div className="flex flex-col items-end">
          <span className="text-muted-foreground uppercase tracking-wider text-[10px] font-bold">Progress</span>
          <span className="text-xl font-headline font-bold text-foreground">{questionNumber}/15</span>
        </div>
      </div>
      
      <div className="relative h-2">
        <Progress value={confidence} className="h-full bg-white/5 overflow-hidden" />
        <motion.div
          className="absolute inset-0 bg-primary/20 blur-md pointer-events-none"
          animate={{
            opacity: [0.1, 0.3, 0.1],
            width: `${confidence}%`
          }}
          transition={{ duration: 2, repeat: Infinity }}
        />
      </div>
    </div>
  );
}