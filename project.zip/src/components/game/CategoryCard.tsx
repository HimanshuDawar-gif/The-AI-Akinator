'use client';

import { motion } from 'framer-motion';
import { Trophy, Users, History, Sparkles } from 'lucide-react';
import { Category } from '@/lib/game-store';

interface CategoryCardProps {
  id: Category;
  title: string;
  description: string;
  onSelect: (id: Category) => void;
}

export default function CategoryCard({ id, title, description, onSelect }: CategoryCardProps) {
  const getIcon = () => {
    switch (id) {
      case 'player': return <Users className="w-6 h-6" />;
      case 'team': return <Trophy className="w-6 h-6" />;
      case 'match': return <History className="w-6 h-6" />;
      default: return <Sparkles className="w-6 h-6" />;
    }
  };

  return (
    <motion.button
      whileHover={{ y: -5, scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      onClick={() => onSelect(id)}
      className="group relative flex flex-col items-start p-6 text-left glass rounded-2xl hover:border-primary/50 transition-colors overflow-hidden"
    >
      <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-30 transition-opacity">
        {getIcon()}
      </div>
      
      <div className="mb-4 p-3 rounded-xl bg-primary/10 text-primary group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
        {getIcon()}
      </div>
      
      <h3 className="text-xl font-headline font-bold mb-2 group-hover:text-primary transition-colors">
        {title}
      </h3>
      
      <p className="text-sm text-muted-foreground leading-relaxed">
        {description}
      </p>
      
      <div className="mt-6 flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-primary opacity-0 group-hover:opacity-100 transition-opacity">
        Select Category 
        <motion.span animate={{ x: [0, 5, 0] }} transition={{ repeat: Infinity, duration: 1.5 }}>
          →
        </motion.span>
      </div>
    </motion.button>
  );
}