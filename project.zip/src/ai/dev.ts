import { config } from 'dotenv';
config();

import '@/ai/flows/ai-final-guess-logic.ts';
import '@/ai/flows/ai-adaptive-personality.ts';
import '@/ai/flows/ai-dynamic-question-engine.ts';