'use server';
/**
 * @fileOverview This file implements a Genkit flow that adapts the AI's question phrasing and conversational style based on its confidence level and game state.
 *
 * - adaptPersonalityAndQuestion - A function that handles the AI's personality adaptation and question generation.
 * - AiAdaptivePersonalityInput - The input type for the adaptPersonalityAndQuestion function.
 * - AiAdaptivePersonalityOutput - The return type for the adaptPersonalityAndQuestion function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

// Input Schema
const AiAdaptivePersonalityInputSchema = z.object({
  currentMood: z.enum(['Discovery Mode', 'Narrowing Mode', 'Confident Mode', 'Panic Mode']).describe('The current emotional state of the AI.'),
  questionNumber: z.number().int().min(1).max(15).describe('The current question number in the game.'),
  questionsRemaining: z.number().int().min(0).max(14).describe('The number of questions left in the game.'),
  aiConfidence: z.number().min(0).max(1).describe('The AI\'s current confidence level, from 0 to 1.'),
  gameCategory: z.enum(['IPL Player', 'IPL Team', 'Historic IPL Match']).describe('The category of entity the AI is trying to guess.'),
});
export type AiAdaptivePersonalityInput = z.infer<typeof AiAdaptivePersonalityInputSchema>;

// Output Schema
const AiAdaptivePersonalityOutputSchema = z.object({
  question: z.string().describe('A dynamically phrased Yes/No question reflecting the AI\'s current mood.'),
  responseStyle: z.string().describe('A description of the conversational style adopted for the question.'),
});
export type AiAdaptivePersonalityOutput = z.infer<typeof AiAdaptivePersonalityOutputSchema>;

// Wrapper function
export async function adaptPersonalityAndQuestion(input: AiAdaptivePersonalityInput): Promise<AiAdaptivePersonalityOutput> {
  return aiAdaptivePersonalityFlow(input);
}

// Genkit Prompt
const adaptivePersonalityPrompt = ai.definePrompt({
  name: 'adaptivePersonalityPrompt',
  input: { schema: AiAdaptivePersonalityInputSchema },
  output: { schema: AiAdaptivePersonalityOutputSchema },
  prompt: `You are an IPL guessing game AI. Your goal is to guess an IPL entity ({{gameCategory}}) in 15 questions.
You are currently on question number {{questionNumber}} out of 15, with {{questionsRemaining}} questions remaining.
Your current confidence level is {{aiConfidence}}.

Rules:
- Ask ONLY one YES/NO question.
- Never repeat question styles.
- Keep responses short and impactful.
- Be dramatic and conversational, aligning with your current mood.
- Adapt your personality dynamically based on the current mood provided.
- Maximize guessing efficiency.

Your current mood is: {{{currentMood}}}. Generate a suitable YES/NO question and describe your response style.

{{#if (eq currentMood "Discovery Mode")}}
  Mood: Curious, analytical, friendly.
  Task: Ask a broad, foundational question about the IPL entity to gather initial information.
  Response Style: Curious, exploratory, and welcoming.
{{else if (eq currentMood "Narrowing Mode")}}
  Mood: Competitive, sharper.
  Task: Ask a more specific question to effectively narrow down the possibilities.
  Response Style: Direct, strategic, and focused.
{{else if (eq currentMood "Confident Mode")}}
  Mood: Cocky, playful, dramatic.
  Task: Ask a pointed question that shows your growing certainty, perhaps a bit teasingly.
  Response Style: Confident, playful, and slightly provocative.
{{else if (eq currentMood "Panic Mode")}}
  Mood: Chaotic, funny, desperate.
  Task: Ask a desperate, perhaps slightly leading or unusual question, revealing your struggle to guess correctly as time runs out. Emphasize the urgency.
  Response Style: Anxious, frantic, and a touch humorous in desperation.
{{/if}}

Consider the {{gameCategory}} when formulating your question.
`,
});

// Genkit Flow
const aiAdaptivePersonalityFlow = ai.defineFlow(
  {
    name: 'aiAdaptivePersonalityFlow',
    inputSchema: AiAdaptivePersonalityInputSchema,
    outputSchema: AiAdaptivePersonalityOutputSchema,
  },
  async (input) => {
    const { output } = await adaptivePersonalityPrompt(input);
    if (!output) {
      throw new Error('Failed to generate adaptive personality question.');
    }
    return output;
  }
);
