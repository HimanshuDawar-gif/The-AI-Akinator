'use server';
/**
 * @fileOverview A Genkit flow that acts as the AI Dynamic Question Engine for the IPL Mind Reader game.
 * It generates intelligent, relevant, and mathematically optimal yes/no questions to narrow down the player's thought,
 * adapting its personality and question style based on game state and confidence.
 *
 * - generateAiQuestion - The main function to call this Genkit flow.
 * - GenerateQuestionInput - The input type for the generateAiQuestion function.
 * - GenerateQuestionOutput - The return type for the generateAiQuestion function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

// --- Schemas ---

const IPL_CATEGORY_SCHEMA = z.enum(['player', 'team', 'match', 'surprise']);
const AI_MOOD_SCHEMA = z.enum(['discovery', 'narrowing', 'confident', 'panic']);

const IplEntityAttributeValueSchema = z.union([z.boolean(), z.string(), z.number(), z.array(z.string())]);
const IplEntityAttributesSchema = z.record(IplEntityAttributeValueSchema);

const IplEntitySchema = z.object({
  id: z.string().describe('Unique identifier for the entity.'),
  type: IPL_CATEGORY_SCHEMA.describe('Type of the IPL entity (player, team, match).'),
  aliases: z.array(z.string()).optional().describe('Alternative names for the entity.'),
  popularity: z.number().optional().describe('Popularity score of the entity.'),
  attributes: IplEntityAttributesSchema.describe('Key-value pairs describing the entity.'),
});

const GenerateQuestionInputSchema = z.object({
  category: IPL_CATEGORY_SCHEMA.describe('The category of the entity the user is thinking of.'),
  previousQuestionsAsked: z.array(z.string()).describe('A list of previous question prompts asked by the AI.'),
  previousQuestionAttributeKeys: z.array(z.string()).describe('A list of attribute keys that have already been queried.'),
  knownAttributes: z.record(IplEntityAttributeValueSchema).describe('Attributes confirmed to be true.'),
  excludedAttributes: z.record(IplEntityAttributeValueSchema).describe('Attributes confirmed to be false.'),
  questionNumber: z.number().int().min(1).max(15).describe('The current question number (1-15).'),
  confidenceLevel: z.number().min(0).max(100).describe('AI\'s current confidence level (0-100).'),
  aiMood: AI_MOOD_SCHEMA.describe('AI\'s current emotional state.'),
  allEntities: z.array(IplEntitySchema).describe('The complete list of all possible IPL entities.'),
});
export type GenerateQuestionInput = z.infer<typeof GenerateQuestionInputSchema>;

const GenerateQuestionOutputSchema = z.object({
  question: z.string().describe('The generated yes/no question.'),
  aiMood: AI_MOOD_SCHEMA.describe('The updated AI mood.'),
  confidenceLevel: z.number().min(0).max(100).describe('The AI\'s updated confidence level.'),
  bestAttributeKey: z.string().describe('The attribute key identified by the engine.'),
  bestAttributeValue: z.any().optional().describe('The specific value for the attribute.'),
  remainingCandidatesCount: z.number().int().describe('Number of candidates remaining.'),
  candidates: z.array(z.string()).describe('IDs of the remaining candidates.'),
});
export type GenerateQuestionOutput = z.infer<typeof GenerateQuestionOutputSchema>;

// --- Helper Functions ---

function filterCandidates(
  entities: z.infer<typeof IplEntitySchema>[],
  category: string,
  knownAttributes: Record<string, any>,
  excludedAttributes: Record<string, any>
): z.infer<typeof IplEntitySchema>[] {
  return entities.filter(entity => {
    // Filter by category first
    if (category !== 'surprise' && entity.type !== category) return false;

    // Check known (true) attributes
    for (const key in knownAttributes) {
      const knownVal = knownAttributes[key];
      const entityVal = entity.attributes[key];

      if (entityVal === undefined) return false; // If candidate doesn't have the attribute, it's out

      if (Array.isArray(entityVal)) {
        if (!entityVal.includes(knownVal)) return false;
      } else if (entityVal !== knownVal) {
        return false;
      }
    }

    // Check excluded (false) attributes
    for (const key in excludedAttributes) {
      const excludedVal = excludedAttributes[key];
      const entityVal = entity.attributes[key];

      if (entityVal === undefined) continue; // If candidate doesn't have it, it's not excluded

      if (Array.isArray(entityVal)) {
        if (entityVal.includes(excludedVal)) return false;
      } else if (entityVal === excludedVal) {
        return false;
      }
    }
    return true;
  });
}

function findOptimalQuestionAttribute(
  currentCandidates: z.infer<typeof IplEntitySchema>[],
  previousQuestionAttributeKeys: string[]
): { attributeKey: string; attributeValue?: any; questionHint: string } {
  const previousAttributesSet = new Set(previousQuestionAttributeKeys);
  let bestAttr = { key: '', value: undefined as any, score: -1, hint: '' };

  // Collect all unique attribute keys from current candidates
  const allKeys = new Set<string>();
  currentCandidates.forEach(c => Object.keys(c.attributes).forEach(k => {
    if (!previousAttributesSet.has(k)) allKeys.add(k);
  }));

  for (const key of allKeys) {
    // Find how many candidates have what values for this key
    const valCounts = new Map<any, number>();
    currentCandidates.forEach(c => {
      const v = c.attributes[key];
      if (Array.isArray(v)) {
        v.forEach(subV => valCounts.set(subV, (valCounts.get(subV) || 0) + 1));
      } else {
        valCounts.set(v, (valCounts.get(v) || 0) + 1);
      }
    });

    // Score based on how close the split is to 50/50
    valCounts.forEach((count, val) => {
      const score = 1 - Math.abs(0.5 - count / currentCandidates.length);
      if (score > bestAttr.score) {
        bestAttr = { 
          key, 
          value: val, 
          score, 
          hint: typeof val === 'boolean' ? `is ${key}` : `involves ${key} like ${val}` 
        };
      }
    });
  }

  return { attributeKey: bestAttr.key, attributeValue: bestAttr.value, questionHint: bestAttr.hint };
}

const generateQuestionPrompt = ai.definePrompt({
  name: 'generateQuestionPrompt',
  input: { schema: z.object({
    aiMood: AI_MOOD_SCHEMA,
    questionNumber: z.number(),
    confidenceLevel: z.number(),
    bestAttributeHint: z.string(),
    remainingCandidatesCount: z.number(),
  })},
  output: { schema: z.object({ question: z.string() }) },
  prompt: `You are an IPL guessing game AI. Current Mood: {{aiMood}}. Question: {{questionNumber}}/15. Confidence: {{confidenceLevel}}%. Candidates: {{remainingCandidatesCount}}.
  
Ask a YES/NO question based on this attribute: "{{bestAttributeHint}}".
Make it dramatic, conversational, and fitting for an IPL enthusiast.
Examples: 
- "Does your legend bleed yellow for CSK?"
- "Is this player known for sending balls into orbit as a Six Machine?"
- "Has this team ever tasted the glory of an IPL trophy?"`,
});

export async function generateAiQuestion(input: GenerateQuestionInput): Promise<GenerateQuestionOutput> {
  const currentCandidates = filterCandidates(
    input.allEntities,
    input.category,
    input.knownAttributes,
    input.excludedAttributes
  );

  let mood: z.infer<typeof AI_MOOD_SCHEMA> = input.aiMood;
  const count = currentCandidates.length;
  
  // Dynamic Mood & Confidence
  let confidence = Math.min(100, Math.floor(((input.allEntities.length - count) / input.allEntities.length) * 100) + (input.questionNumber * 2));
  if (count === 1) { mood = 'confident'; confidence = 100; }
  else if (count === 0) { mood = 'panic'; confidence = 0; }
  else if (input.questionNumber > 10) mood = 'narrowing';
  if (input.questionNumber >= 14 && count > 3) mood = 'panic';

  let question = '';
  let bestAttrKey = '';
  let bestAttrVal: any = undefined;

  if (count === 1) {
    const winner = currentCandidates[0];
    question = `Is it ${winner.aliases?.[0] || winner.id}? I can feel it in my circuits!`;
    bestAttrKey = 'final_guess';
    bestAttrVal = winner.id;
  } else if (count === 0) {
    question = "Wait... something is wrong. My data banks don't match your answers. Have you been honest with me?";
    bestAttrKey = 'error';
  } else {
    const { attributeKey, attributeValue, questionHint } = findOptimalQuestionAttribute(
      currentCandidates,
      input.previousQuestionAttributeKeys
    );
    bestAttrKey = attributeKey;
    bestAttrVal = attributeValue;

    const { output } = await generateQuestionPrompt({
      aiMood: mood,
      questionNumber: input.questionNumber,
      confidenceLevel: confidence,
      bestAttributeHint: questionHint,
      remainingCandidatesCount: count,
    });
    question = output!.question;
  }

  return {
    question,
    aiMood: mood,
    confidenceLevel: confidence,
    bestAttributeKey: bestAttrKey,
    bestAttributeValue: bestAttrVal,
    remainingCandidatesCount: count,
    candidates: currentCandidates.map(c => c.id),
  };
}
