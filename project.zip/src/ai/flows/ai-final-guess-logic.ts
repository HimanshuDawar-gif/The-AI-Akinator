'use server';
/**
 * @fileOverview This file implements the Genkit flow for the AI to make a decisive final guess.
 *
 * - aiFinalGuessLogic - A function that handles the AI's final guess process.
 * - AiFinalGuessLogicInput - The input type for the aiFinalGuessLogic function.
 * - AiFinalGuessLogicOutput - The return type for the aiFinalGuessLogic function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const AiFinalGuessLogicInputSchema = z.object({
  category: z.enum(['player', 'team', 'match', 'surprise_me']).describe('The category of the entity being guessed (player, team, or match).'),
  candidates: z.array(z.string()).describe('A list of possible IPL entities the AI has narrowed down to.'),
});
export type AiFinalGuessLogicInput = z.infer<typeof AiFinalGuessLogicInputSchema>;

const AiFinalGuessLogicOutputSchema = z.object({
  finalGuess: z.string().describe('The AI\'s confident final guess for the IPL entity.'),
  reasoning: z.string().describe('A dramatic and decisive justification for the AI\'s final guess.'),
});
export type AiFinalGuessLogicOutput = z.infer<typeof AiFinalGuessLogicOutputSchema>;

export async function aiFinalGuessLogic(input: AiFinalGuessLogicInput): Promise<AiFinalGuessLogicOutput> {
  return aiFinalGuessFlow(input);
}

const prompt = ai.definePrompt({
  name: 'aiFinalGuessPrompt',
  input: { schema: AiFinalGuessLogicInputSchema },
  output: { schema: AiFinalGuessLogicOutputSchema },
  prompt: `You are an IPL guessing game AI in its final moments of making a guess. You have narrowed down the possibilities to the following:

Candidates:
{{#each candidates}}
- {{{this}}}
{{/each}}

Your task is to select the MOST LIKELY candidate from this list and declare your final guess with utmost confidence and dramatic flair. Provide a brief, decisive reasoning for your choice.

Example Output Format:
{
  "finalGuess": "MS Dhoni",
  "reasoning": "After meticulous deduction and analyzing every strategic move, there can only be one legend. I am supremely confident it is none other than MS Dhoni!"
}

Now, make your final, unshakeable declaration for the {{{category}}} category!`,
});

const aiFinalGuessFlow = ai.defineFlow(
  {
    name: 'aiFinalGuessFlow',
    inputSchema: AiFinalGuessLogicInputSchema,
    outputSchema: AiFinalGuessLogicOutputSchema,
  },
  async (input) => {
    const { output } = await prompt(input);
    return output!;
  }
);
